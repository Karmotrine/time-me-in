--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE alphabet_timemein;
--
-- Name: alphabet_timemein; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE alphabet_timemein WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Philippines.1252';


ALTER DATABASE alphabet_timemein OWNER TO postgres;

\connect alphabet_timemein

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE alphabet_timemein; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE alphabet_timemein IS 'timemein';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    id uuid NOT NULL,
    name text,
    address text,
    contact text,
    employ_status text
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: time_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_record (
    event_id integer NOT NULL,
    employee_id uuid,
    date date,
    log_in time(0) without time zone,
    log_out time(0) without time zone,
    total_hours integer
);


ALTER TABLE public.time_record OWNER TO postgres;

--
-- Name: time_record_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.time_record_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.time_record_event_id_seq OWNER TO postgres;

--
-- Name: time_record_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.time_record_event_id_seq OWNED BY public.time_record.event_id;


--
-- Name: time_record event_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_record ALTER COLUMN event_id SET DEFAULT nextval('public.time_record_event_id_seq'::regclass);


--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (id, name, address, contact, employ_status) FROM stdin;
\.
COPY public.employee (id, name, address, contact, employ_status) FROM '$$PATH$$/2992.dat';

--
-- Data for Name: time_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_record (event_id, employee_id, date, log_in, log_out, total_hours) FROM stdin;
\.
COPY public.time_record (event_id, employee_id, date, log_in, log_out, total_hours) FROM '$$PATH$$/2994.dat';

--
-- Name: time_record_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_record_event_id_seq', 24, true);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- Name: time_record time_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_record
    ADD CONSTRAINT time_record_pkey PRIMARY KEY (event_id);


--
-- Name: fki_record_to_employee_employ_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_record_to_employee_employ_id ON public.time_record USING btree (employee_id);


--
-- Name: time_record record_to_employee_employ_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_record
    ADD CONSTRAINT record_to_employee_employ_id FOREIGN KEY (employee_id) REFERENCES public.employee(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

